#include <iostream>
using namespace std;
#include <algorithm>
#include <fstream>
#include <vector>
#include <ctime>
#include <cmath>
#include "declarations.h"


void folds_stats::logavg() {
    // for random num generating. Only needs to be called once.
    srand(static_cast <unsigned> (time(0)));

    // Initialize values for later to prevent re-initializing
    // n = number of folds
    int n = 14;
    float sizeo; 
    vector<float> segs_i; 
    vector<float> segs_o;
    vector<float> tmp; 

    // fold count is just a vector of integers increasing by 1. Then convert to log scale
    vector<float> f;
    vector<float> logf;
    for (float i = 0; i < n; i++) {
        f.insert(f.end(), {i + 1});
        logf.insert(logf.end(), { log(f[i]) });
    }

    // Initialize vecs: creases, log(creases), average(log(creases))
    vector<float> c;
    vector<float> logc;
    vector<float> cavg;
    for (int i = 0; i < n; i++) {
        cavg.insert(cavg.end(), { 0 });
        c.insert(c.end(), { 0 });
        logc.insert(logc.end(), { 0 });
    } 

    // loop (instance) times to average log(crease values) for accurate statistics.
    const int instance = 30; 
    for (int j = 1; j <= instance; j++) {
        segs_i = { 0,1 };
        // Fold n times. Count creases and take their logs
        for (int i = 0; i < n; i++) {
            segs_o = fold(segs_i);
            sizeo = segs_o.size();
            // number of creases is number of segments - 1 (should add code to not execute this if x = 0 or 1 -- then log(0) = -inf)
            c[i] = (sizeo / 2) - 1;
            logc[i] = log(c[i]);
            /*cavg[i] += logc[i];*/
            cavg[i] += c[i];
            segs_i = segs_o;
        }
    }
    // Print to file to be used in gnuplot
    ofstream data;
    data.open("data.txt");
    // Average the logs of crease values 
    for (int i = 0; i < n; i++) {
        cavg[i] /= instance;
        data << f[i] << ' ' << cavg[i] << '\n';
    }
    data.close();
}

// fold function.  
vector<float> folds_stats::fold(vector<float> segs_in) {
    // segs_out has to be initialized here, not in class creation since segs_out is used as a different thing in logavg() definition
    vector<float> segs_out;
    // 1 for fold direction left; 0 for right. rand() is seeded in main()
    direct = rand() % 2;
   
    // generates random fold pos.
    LO = getmin(segs_in);
    HI = getmax(segs_in);
    x = LO + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HI - LO)));

    // check if x in outermost segment
    if (LO < x && x < HI) {

        // loop through each segment
        size = segs_in.size();
        for (int i = 0; i < size; i += 2) {

            // identify i'th segment
            seg_l = segs_in[i];
            seg_r = segs_in[i + 1];

            // right fold
            if (direct == 0) {
                if (seg_l < x && x < seg_r) {
                    segs_out.insert(segs_out.end(), { x, (2 * x) - seg_l });
                    segs_out.insert(segs_out.end(), { x, seg_r });
                }
                else if (x > seg_r) {
                    segs_out.insert(segs_out.end(), { (2 * x) - seg_r, (2 * x) - seg_l });
                }
                else if (x <= seg_l) {
                    segs_out.insert(segs_out.end(), { seg_l, seg_r });
                }
                else if (x == seg_r) {
                    segs_out.insert(segs_out.end(), { x, (2 * x) - seg_l });
                }
            }
            // left fold
            else if (direct == 1) {
                if (seg_l < x && x < seg_r) {
                    segs_out.insert(segs_out.end(), { seg_l, x });
                    segs_out.insert(segs_out.end(), { (2 * x) - seg_r, x });
                }
                else if (x < seg_l) {
                    segs_out.insert(segs_out.end(), { (2 * x) - seg_r, (2 * x) - seg_l });
                }
                else if (x >= seg_r) {
                    segs_out.insert(segs_out.end(), { seg_l, seg_r });
                }
                else if (x == seg_l) {
                    segs_out.insert(segs_out.end(), { (2 * x) - seg_r, x });
                }
            }
        }
    }
    // else: don't fold at outermost endpoints. Then crease # does not change
    else {
        segs_out = segs_in;
    }
    return segs_out;
}

// Find min element at beginning of fold() 
float folds_stats::getmin(vector<float> segs_in) {
    size = segs_in.size();
    min = segs_in[0];
    for (int i = 1; i < size; i++) {
        if (segs_in[i] < min) {
            min = segs_in[i];
        }
    }
    return min;
}

// Find max element at beginning of fold()
float folds_stats::getmax(vector<float> segs_in) {
    size = segs_in.size();
    max = segs_in[0];
    for (int i = 1; i < size; i++) {
        if (segs_in[i] > max) {
            max = segs_in[i];
        }
    }
    return max;
}


// display vec function. For debug purposes only
void folds_stats::display(vector<float> arr) {
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << '\n';
    }
}


