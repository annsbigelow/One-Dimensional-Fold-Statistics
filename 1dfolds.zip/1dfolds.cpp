#include <iostream>
using namespace std;
#include "declarations.h"


int main() {
    folds_stats fs; 
    
    /*vector<float> cavg = fs.logavg();
    fs.display(cavg); */
    fs.logavg();
    
    return 0;
}


